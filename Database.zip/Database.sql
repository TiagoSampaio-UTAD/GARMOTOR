/* BASE DE DADOS GARMOTOR 2026 - VERSÃO FINAL CORRIGIDA 
   Inclui: Estrutura de Vendedores, Veículos e Contas Oficiais Ativas.
*/

-- 1. CONFIGURAÇÃO INICIAL
IF NOT EXISTS (SELECT * FROM sys.databases WHERE name = 'GARMOTOR')
BEGIN
    CREATE DATABASE GARMOTOR;
END
GO

USE GARMOTOR;
GO

-- 2. LIMPEZA TOTAL (RESET) - Sintaxe corrigida para SQL Server
IF OBJECT_ID('dbo.Veiculos', 'U') IS NOT NULL DROP TABLE dbo.Veiculos;
IF OBJECT_ID('dbo.Vendedores', 'U') IS NOT NULL DROP TABLE dbo.Vendedores;
GO

-- 3. TABELA DE VENDEDORES
CREATE TABLE Vendedores (
    Id INT PRIMARY KEY IDENTITY(1,1),
    Nome NVARCHAR(100) NOT NULL,
    Email NVARCHAR(100) UNIQUE NOT NULL,
    Senha NVARCHAR(255) NOT NULL,
    NomeLoja NVARCHAR(100),
    EmailConfirmado BIT DEFAULT 0, -- 0 = Aguarda Confirmação / 1 = Ativo
    DataCriacao DATETIME DEFAULT GETDATE()
);
GO

-- 4. TABELA DE VEÍCULOS
CREATE TABLE Veiculos (
    Id INT PRIMARY KEY IDENTITY(1,1),
    VendedorId INT NOT NULL,
    Marca NVARCHAR(50),
    Modelo NVARCHAR(50),
    Ano INT,
    Kms INT,
    Combustivel NVARCHAR(30),
    Caixa NVARCHAR(30),
    Cor NVARCHAR(30),
    Preco DECIMAL(10, 2),
    Descricao NVARCHAR(MAX),
    ImagemCapa NVARCHAR(MAX), 
    Estado NVARCHAR(20) DEFAULT 'Ativo',
    DataPublicacao DATETIME DEFAULT GETDATE(),

    CONSTRAINT FK_VendedorVeiculo FOREIGN KEY (VendedorId) 
    REFERENCES Vendedores(Id) ON DELETE CASCADE
);
GO

-- 5. INSERIR VENDEDORES OFICIAIS
-- Usamos EmailConfirmado = 1 para que possas logar logo
INSERT INTO Vendedores (Nome, Email, Senha, NomeLoja, EmailConfirmado) 
VALUES 
('Tiago Sampaio', 'tiagoalvessampaio12@gmail.com', 'Tiago1.', 'Stand do Tiago', 1),
('GARMOTOR', 'geral@garmotor.com', 'garmotor2026', 'Garmotor Oficial', 1);
GO

-- 6. VERIFICAÇÃO DE DADOS
SELECT * FROM Vendedores;
SELECT * FROM Veiculos;