const express = require('express');
const sql = require('mssql');
const cors = require('cors');
const bodyParser = require('body-parser');
const nodemailer = require('nodemailer');

const app = express();

// Aumentar o limite para suportar imagens em Base64
app.use(bodyParser.json({ limit: '200mb' }));
app.use(bodyParser.urlencoded({ limit: '200mb', extended: true }));
app.use(cors());

// Configuração da Base de Dados
const dbConfig = {
    user: 'sa',
    password: 'Garmotor2026!',
    server: 'localhost',
    database: 'GARMOTOR',
    options: { encrypt: false, trustServerCertificate: true },
    port: 1433
};

// Configuração do Nodemailer (IMPORTANTE: Usa uma "Senha de App")
const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: 'tiagoalvessampaio12@gmail.com',
        pass: 'PALAVRA_PASSE_APP_AQUI' // Deves gerar isto na tua conta Google
    }
});

// --- UTILIZADORES ---

// Registar com envio de email de confirmação
app.post('/api/registar', async (req, res) => {
    try {
        const { nome, email, pass, loja } = req.body;
        let pool = await sql.connect(dbConfig);
        
        let check = await pool.request().input('e', sql.NVarChar, email).query('SELECT Id FROM Vendedores WHERE Email = @e');
        if (check.recordset.length > 0) return res.status(400).json({ mensagem: "Este e-mail já está registado." });

        // Nota: NomeLoja e Nome usados conforme os teus prints de SQL
        await pool.request()
            .input('n', sql.NVarChar, nome)
            .input('e', sql.NVarChar, email)
            .input('s', sql.NVarChar, pass)
            .input('l', sql.NVarChar, loja)
            .query('INSERT INTO Vendedores (Nome, Email, Senha, NomeLoja, EmailConfirmado, Aprovado) VALUES (@n, @e, @s, @l, 0, 1)');

        const token = Buffer.from(email).toString('base64');
        const link = `http://localhost:3000/api/confirmar/${token}`;

        await transporter.sendMail({
            from: '"GARMOTOR" <tiagoalvessampaio12@gmail.com>',
            to: email,
            subject: 'Confirma a tua conta - GARMOTOR',
            html: `<h2>Bem-vindo à GARMOTOR!</h2><p>Ativa a tua conta aqui:</p>
                   <a href="${link}" style="background: #007aff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">Confirmar Email</a>`
        });

        res.json({ mensagem: "Conta criada! Verifica o teu e-mail." });
    } catch (err) { 
        res.status(500).json({ mensagem: "Erro: " + err.message }); 
    }
});

// Confirmar Email
app.get('/api/confirmar/:token', async (req, res) => {
    try {
        const email = Buffer.from(req.params.token, 'base64').toString('ascii');
        let pool = await sql.connect(dbConfig);
        await pool.request().input('e', sql.NVarChar, email).query('UPDATE Vendedores SET EmailConfirmado = 1 WHERE Email = @e');
        res.send('<h1>Conta ativada!</h1><p>Podes fechar esta página e fazer login.</p>');
    } catch (err) { res.status(500).send("Erro na ativação."); }
});

// LOGIN (Corrigido para evitar "undefined")
app.post('/api/login', async (req, res) => {
    try {
        let pool = await sql.connect(dbConfig);
        let result = await pool.request()
            .input('email', sql.NVarChar, req.body.email)
            .input('pass', sql.NVarChar, req.body.pass)
            .query('SELECT Nome, Email, NomeLoja, EmailConfirmado FROM Vendedores WHERE Email = @email AND Senha = @pass');

        if (result.recordset.length > 0) {
            const user = result.recordset[0];
            
            if (user.EmailConfirmado == 0) {
                return res.status(403).json({ mensagem: "Por favor, confirma o teu email primeiro!" });
            }

            // Retornamos os nomes exatos que o teu Authentication.html espera
            res.json({ 
                nome: user.Nome, 
                email: user.Email, 
                loja: user.NomeLoja 
            });
        } else {
            res.status(401).json({ mensagem: "E-mail ou palavra-passe incorretos." });
        }
    } catch (err) {
        res.status(500).json({ mensagem: "Erro no servidor: " + err.message });
    }
});

// --- VEÍCULOS ---

// Listar todos
app.get('/api/veiculos', async (req, res) => {
    try {
        let pool = await sql.connect(dbConfig);
        let result = await pool.request().query('SELECT * FROM Veiculos ORDER BY Id DESC');
        res.json(result.recordset);
    } catch (err) { res.status(500).send(err.message); }
});

// Adicionar Veículo (Corrigida e Testada)
app.post('/api/veiculos/adicionar', async (req, res) => {
    try {
        const d = req.body;
        let pool = await sql.connect(dbConfig);
        
        let vendedor = await pool.request()
            .input('email', sql.NVarChar, d.vendedorEmail)
            .query('SELECT Id FROM Vendedores WHERE Email = @email');

        if (vendedor.recordset.length > 0) {
            await pool.request()
                .input('vId', sql.Int, vendedor.recordset[0].Id)
                .input('ma', sql.NVarChar, d.marca)
                .input('mo', sql.NVarChar, d.modelo)
                .input('an', sql.Int, d.ano)
                .input('km', sql.Int, d.kms)
                .input('co', sql.NVarChar, d.combustivel)
                .input('ca', sql.NVarChar, d.caixa)
                .input('cr', sql.NVarChar, d.cor)
                .input('pr', sql.Decimal(10,2), d.preco)
                .input('desc', sql.NVarChar(sql.MAX), d.descricao)
                .input('im', sql.NVarChar(sql.MAX), d.imagens)
                .query(`INSERT INTO Veiculos (VendedorId, Marca, Modelo, Ano, Kms, Combustivel, Caixa, Cor, Preco, Descricao, ImagemCapa) 
                        VALUES (@vId, @ma, @mo, @an, @km, @co, @ca, @cr, @pr, @desc, @im)`);
            
            res.json({ mensagem: "Veículo publicado com sucesso!" });
        } else { 
            res.status(404).json({ mensagem: "Vendedor não identificado. Faça login de novo." }); 
        }
    } catch (err) { 
        res.status(500).json({ mensagem: "Erro ao salvar veículo: " + err.message }); 
    }
});

// Detalhes do Veículo
// Obter detalhes de um veículo (VERSÃO CORRIGIDA)
app.get('/api/veiculos/:id', async (req, res) => {
    try {
        let pool = await sql.connect(dbConfig);
        let result = await pool.request()
            .input('id', sql.Int, req.params.id)
            .query(`
                SELECT V.*, Vend.Nome as VendedorNome 
                FROM Veiculos V 
                LEFT JOIN Vendedores Vend ON V.VendedorId = Vend.Id 
                WHERE V.Id = @id
            `);

        if (result.recordset.length > 0) {
            res.json(result.recordset[0]);
        } else {
            res.status(404).json({ mensagem: "Veículo não encontrado." });
        }
    } catch (err) { 
        res.status(500).send("Erro no servidor: " + err.message); 
    }
});

app.listen(3000, () => console.log("🚀 GARMOTOR ON: Porta 3000"));